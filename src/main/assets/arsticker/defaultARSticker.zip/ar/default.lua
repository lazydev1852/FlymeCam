app_controller = ae.ARApplicationController:shared_instance()
app_controller:require('./scripts/include.lua')
app = AR:create_application(AppType.Slam, 'heitongzi')
app:load_scene_from_json('res/main.json','demo_scene')
scene = app:get_current_scene()

scene.root.on_update = function()    
  local data = app_controller:native_data_pipe()    
  local slam_data = data["slam"]    
  if (slam_data ~= nil) then        
    scene.heitongzi:set_visible(true)  
  end
end

app.on_loading_finish = function()
	app:onArInit()
    EDLOG('资源包加载完成后回调,相当于主函数')
    Event:addEventListener("mz_model_reset_pos", function(evt)
        ARLOG("mz_model_reset_pos  111")
           app:relocate_current_scene()
           app.slam:slam_reset(0.5,0.6,500,3)
           reset_slam_with_face_to_camera(100)
           local application ae.ARApplication:shared_application()
           application:reset()
    end) 
    scene.heitongzi:pod_anim():start()          
end

-- app.onArInit为编辑工具自动生成的方法，请勿删除/修改方法內的内容
app.onArInit = function(self)
-- 框架方法，请勿删除或修改
end

